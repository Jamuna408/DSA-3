import java.util.ArrayList;
import java.util.List;

/**
 * Smith-Waterman local sequence alignment algorithm.
 * Module: CO3 - Advanced Dynamic Programming
 * Topic : "Sequence alignment for genome data: Needleman-Wunsch (global),
 *          Smith-Waterman (local); the gap-penalty discussion."
 *
 * Uses a 2D dynamic-programming matrix (overlapping subproblems + optimal
 * substructure) to find the highest-scoring LOCAL alignment between two
 * sequences, then performs a traceback to reconstruct the aligned strings.
 */
public class SmithWaterman {

    private final int matchScore;
    private final int mismatchScore; // stored as a negative penalty
    private final int gapPenalty;    // stored as a positive value, subtracted

    private int[][] H;               // DP / scoring matrix
    private char[][] traceDir;       // 'D' diag, 'U' up, 'L' left, '0' stop

    public SmithWaterman(int matchScore, int mismatchScore, int gapPenalty) {
        this.matchScore = matchScore;
        this.mismatchScore = mismatchScore;
        this.gapPenalty = gapPenalty;
    }

    /** Runs the algorithm and returns a full AlignmentResult. */
    public AlignmentResult align(String seqA, String seqB) {
        long start = System.nanoTime();

        int n = seqA.length();
        int m = seqB.length();
        H = new int[n + 1][m + 1];
        traceDir = new char[n + 1][m + 1];

        int maxScore = 0;
        int maxI = 0, maxJ = 0;

        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                int s = (seqA.charAt(i - 1) == seqB.charAt(j - 1)) ? matchScore : -mismatchScore;

                int diag = H[i - 1][j - 1] + s;
                int up = H[i - 1][j] - gapPenalty;
                int left = H[i][j - 1] - gapPenalty;

                int best = 0;
                char dir = '0';

                if (diag > best) { best = diag; dir = 'D'; }
                if (up > best)   { best = up;   dir = 'U'; }
                if (left > best) { best = left; dir = 'L'; }

                H[i][j] = best;
                traceDir[i][j] = dir;

                if (best > maxScore) {
                    maxScore = best;
                    maxI = i;
                    maxJ = j;
                }
            }
        }

        // Traceback from the highest scoring cell until a 0 is hit.
        StringBuilder alignedA = new StringBuilder();
        StringBuilder alignedB = new StringBuilder();
        int i = maxI, j = maxJ;

        while (i > 0 && j > 0 && traceDir[i][j] != '0') {
            char dir = traceDir[i][j];
            if (dir == 'D') {
                alignedA.append(seqA.charAt(i - 1));
                alignedB.append(seqB.charAt(j - 1));
                i--; j--;
            } else if (dir == 'U') {
                alignedA.append(seqA.charAt(i - 1));
                alignedB.append('-');
                i--;
            } else { // 'L'
                alignedA.append('-');
                alignedB.append(seqB.charAt(j - 1));
                j--;
            }
        }

        alignedA.reverse();
        alignedB.reverse();

        long elapsedNanos = System.nanoTime() - start;

        return buildResult(alignedA.toString(), alignedB.toString(), maxScore,
                i, j, maxI, maxJ, elapsedNanos);
    }

    private AlignmentResult buildResult(String alignedA, String alignedB, int score,
                                         int startI, int startJ, int endI, int endJ,
                                         long elapsedNanos) {
        int matches = 0, mismatches = 0, gaps = 0;
        for (int k = 0; k < alignedA.length(); k++) {
            char a = alignedA.charAt(k);
            char b = alignedB.charAt(k);
            if (a == '-' || b == '-') gaps++;
            else if (a == b) matches++;
            else mismatches++;
        }
        double similarity = alignedA.length() == 0 ? 0.0
                : (matches * 100.0) / alignedA.length();

        return new AlignmentResult(alignedA, alignedB, score, matches, mismatches,
                gaps, similarity, startI, startJ, endI, endJ, elapsedNanos);
    }

    /** Returns the DP matrix rows as printable strings (for report / demo). */
    public List<String> matrixAsRows(String seqA, String seqB) {
        List<String> rows = new ArrayList<>();
        StringBuilder header = new StringBuilder("      ");
        for (int j = 0; j < seqB.length(); j++) header.append(seqB.charAt(j)).append("   ");
        rows.add(header.toString());

        for (int i = 0; i <= seqA.length(); i++) {
            StringBuilder row = new StringBuilder();
            row.append(i == 0 ? ' ' : seqA.charAt(i - 1)).append(" ");
            for (int j = 0; j <= seqB.length(); j++) {
                row.append(String.format("%3d ", H[i][j]));
            }
            rows.add(row.toString());
        }
        return rows;
    }
}

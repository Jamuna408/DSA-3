/**
 * =====================================================================
 *  GENESCAN: DNA MUTATION & DISEASE VARIANT DETECTOR
 *  Local Sequence Alignment of Healthy vs Patient DNA using the
 *  Smith-Waterman Algorithm
 * =====================================================================
 *
 * Team: B. Jamuna (2520030408), B. Pemesh (2520030388),
 *       P. Anuradha Nandini (2520030171)
 *
 * Idea:
 *   Instead of comparing two arbitrary sequences, this driver compares
 *   a HEALTHY reference gene/protein sequence against a PATIENT sample
 *   that may carry a disease-associated mutation. The same two-stage
 *   pipeline from the original project is reused unchanged:
 *
 *   1) CO2 (String Algorithms) stage: Suffix Array + Kasai LCP array
 *      quickly finds the longest EXACT conserved region shared between
 *      the healthy and patient sequences.
 *   2) CO3 (Advanced Dynamic Programming) stage: Smith-Waterman finds
 *      the best-scoring LOCAL alignment, which is what actually exposes
 *      point mutations, insertions and deletions between the two.
 *
 * Case 1 is real, textbook genetics: Sickle Cell Anaemia is caused by a
 * single point mutation in the HBB gene (codon GAG -> GTG), which
 * changes amino acid 6 of the beta-globin protein from Glutamic acid
 * (Glu/E) to Valine (Val/V). Case 2 shows the same mutation at the
 * protein level. Case 3 is a simplified, clearly-labelled illustrative
 * model (not exact GenBank coordinates) of an in-frame deletion, in the
 * style of the CFTR delta-F508 mutation that causes Cystic Fibrosis,
 * used to demonstrate how Smith-Waterman handles gaps/indels.
 *
 * This is an educational bioinformatics demo, not a diagnostic tool.
 */
public class Main {

    private static final String TITLE =
            "GENESCAN: DNA MUTATION & DISEASE VARIANT DETECTOR";
    private static final String SUBTITLE =
            "Healthy vs Patient Sequence Comparison using Smith-Waterman Local Alignment";

    // ---- Reference (healthy) HBB gene fragment covering codon 6 (Glu) ----
    // Codons: ATG-GTG-CAC-CTG-ACT-CCT-GAG-GAG-AAG-TCT
    //          Met  Val  His  Leu  Thr  Pro  Glu  Glu  Lys  Ser
    // Protein numbering (Met cleaved): Val1-His2-Leu3-Thr4-Pro5-Glu6-Glu7...
    private static final String HEALTHY_HBB_DNA = "ATGGTGCACCTGACTCCTGAGGAGAAGTCT";
    // 0-indexed position of the middle base of the codon-6 "GAG" triplet.
    private static final int MUTATION_INDEX = 19; // sits inside "GAG" -> "GTG"

    // ---- Reference (healthy) beta-globin protein fragment, first 60 aa ----
    private static final String HEALTHY_HBB_PROTEIN =
            "VHLTPEEKSAVTALWGKVNVDEVGGEALGRLLVVYPWTQRFFESFGDLSTPDAVMGNPK";
    private static final String SICKLE_HBB_PROTEIN =
            "VHLTPVEKSAVTALWGKVNVDEVGGEALGRLLVVYPWTQRFFESFGDLSTPDAVMGNPK";

    public static void main(String[] args) {
        printBanner();

        // Build the sickle-cell PATIENT DNA sequence by applying the real
        // E6V point mutation to the healthy reference (GAG -> GTG).
        String sicklePatientDna = applyPointMutation(HEALTHY_HBB_DNA, MUTATION_INDEX, 'T');

        runCase("CASE 1: SICKLE CELL ANAEMIA - HBB GENE (DNA LEVEL)",
                "Healthy Reference (HBB)", HEALTHY_HBB_DNA,
                "Patient Sample (HBB)", sicklePatientDna,
                2, 1, 2, true);

        System.out.println();
        System.out.println("=".repeat(70));
        System.out.println();

        runCase("CASE 2: SICKLE CELL ANAEMIA - BETA-GLOBIN PROTEIN LEVEL",
                "Healthy Reference (Hb-A)", HEALTHY_HBB_PROTEIN,
                "Patient Sample (Hb-S)", SICKLE_HBB_PROTEIN,
                1, 1, 2, false);

        System.out.println();
        System.out.println("=".repeat(70));
        System.out.println();

        // Illustrative in-frame deletion, modelled on Cystic Fibrosis
        // (CFTR delta-F508: loss of a phenylalanine codon). Sequence is a
        // simplified teaching example, not literal GenBank coordinates.
        runCase("CASE 3: CYSTIC FIBROSIS-STYLE MODEL - IN-FRAME DELETION (ILLUSTRATIVE)",
                "Healthy Reference (CFTR-like)", "AATATCATCTTTGGTGTTTCC",
                "Patient Sample (CFTR-like)", "AATATCATCGGTGTTTCC",
                2, 1, 2, false);

        System.out.println();
        System.out.println("=".repeat(70));
        performanceAnalysis();

        System.out.println();
        System.out.println("=".repeat(70));
        multiDiseaseScreening();

        System.out.println();
        System.out.println("=".repeat(70));
        System.out.println("Note: All sequences are simplified/illustrative teaching examples.");
        System.out.println("This program is an educational bioinformatics demo, not a");
        System.out.println("diagnostic or clinical tool.");
    }

    private static void printBanner() {
        String line = "=".repeat(70);
        System.out.println(line);
        System.out.println(center(TITLE, 70));
        System.out.println(center(SUBTITLE, 70));
        System.out.println(line);
    }

    private static String center(String s, int width) {
        int pad = Math.max(0, (width - s.length()) / 2);
        return " ".repeat(pad) + s;
    }

    private static String applyPointMutation(String seq, int index, char newBase) {
        return seq.substring(0, index) + newBase + seq.substring(index + 1);
    }

    /** How a disease's mutation is structurally expressed in the sequence. */
    private enum MutationKind { SUBSTITUTION, DELETION, INSERTION }

    /** One disease's reference gene fragment, mutation model, and scoring parameters. */
    private static final class DiseaseProfile {
        final String id;
        final String name;
        final String gene;
        final String referenceSeq;
        final MutationKind kind;
        final String mutationDescription;
        final int match, mismatch, gap;
        // Mutation parameters: meaning depends on `kind`.
        final int pos;          // SUBSTITUTION: index changed. DELETION/INSERTION: start index.
        final char newBase;     // SUBSTITUTION only.
        final int deleteLen;    // DELETION only.
        final String insertSeq; // INSERTION only.
        final boolean backgroundNoise; // small chance of an extra unrelated substitution.

        DiseaseProfile(String id, String name, String gene, String referenceSeq,
                        MutationKind kind, String mutationDescription,
                        int match, int mismatch, int gap,
                        int pos, char newBase, int deleteLen, String insertSeq,
                        boolean backgroundNoise) {
            this.id = id;
            this.name = name;
            this.gene = gene;
            this.referenceSeq = referenceSeq;
            this.kind = kind;
            this.mutationDescription = mutationDescription;
            this.match = match;
            this.mismatch = mismatch;
            this.gap = gap;
            this.pos = pos;
            this.newBase = newBase;
            this.deleteLen = deleteLen;
            this.insertSeq = insertSeq;
            this.backgroundNoise = backgroundNoise;
        }

        /** Builds one synthetic patient sample: mutated (per this disease's model) or healthy. */
        String generateSample(boolean mutated, java.util.Random rnd) {
            String base = referenceSeq;
            if (mutated) {
                switch (kind) {
                    case SUBSTITUTION: {
                        StringBuilder sb = new StringBuilder(base);
                        sb.setCharAt(pos, newBase);
                        base = sb.toString();
                        break;
                    }
                    case DELETION:
                        base = base.substring(0, pos) + base.substring(pos + deleteLen);
                        break;
                    case INSERTION:
                        base = base.substring(0, pos) + insertSeq + base.substring(pos);
                        break;
                }
            }
            if (backgroundNoise && rnd.nextDouble() < 0.10) { // background sequencing noise
                StringBuilder sb = new StringBuilder(base);
                int p = rnd.nextInt(sb.length());
                char[] bases = {'A', 'C', 'G', 'T'};
                sb.setCharAt(p, bases[rnd.nextInt(4)]);
                base = sb.toString();
            }
            return base;
        }

        String mutationTypeLabel() {
            switch (kind) {
                case SUBSTITUTION: return "Substitution";
                case DELETION: return "Deletion";
                case INSERTION: return "Insertion";
                default: return "Unknown";
            }
        }
    }

    /**
     * Builds a 2,000-entry disease reference panel: the 3 named case-study diseases
     * (Sickle Cell Anaemia, Cystic-Fibrosis-style, Tay-Sachs-style) used in Cases 1-3
     * above, followed by 1,997 additional randomly-generated synthetic disease
     * profiles (random gene symbol, random reference sequence, random mutation
     * type/position). This gives the disease panel the same scale as the patient
     * cohort, while keeping the three real/illustrative teaching cases intact.
     */
    private static DiseaseProfile[] buildDiseasePanel(int totalDiseases) {
        java.util.List<DiseaseProfile> diseases = new java.util.ArrayList<>();

        diseases.add(new DiseaseProfile("SCA", "Sickle Cell Anaemia", "HBB",
                HEALTHY_HBB_DNA, MutationKind.SUBSTITUTION,
                "Codon 6 GAG->GTG (Glu6Val, HbS) - real, textbook point mutation",
                2, 1, 2, MUTATION_INDEX, 'T', 0, null, true));

        diseases.add(new DiseaseProfile("CF", "Cystic Fibrosis (illustrative)", "CFTR-like",
                "AATATCATCTTTGGTGTTTCC", MutationKind.DELETION,
                "3-bp in-frame deletion modelled on CFTR delta-F508 (illustrative, not exact GenBank coordinates)",
                2, 1, 2, 9, ' ', 3, null, false));

        diseases.add(new DiseaseProfile("TSD", "Tay-Sachs (illustrative)", "HEXA-like",
                "GCCATGATCCTGAACGAGTTCAGC", MutationKind.INSERTION,
                "4-bp insertion causing a frameshift-style change (illustrative teaching model)",
                2, 1, 2, 12, ' ', 0, "TATC", false));

        // ---- Randomly generated synthetic diseases, filling the panel up to totalDiseases ----
        java.util.Random genRnd = new java.util.Random(2024);
        char[] bases = {'A', 'C', 'G', 'T'};
        String[] genePrefixes = {"ABC", "SYN", "XRT", "ZLN", "MKB", "QDR", "PVX", "TNF", "GLY", "RSK"};
        String[] nameSuffixes = {"Syndrome", "Disorder", "Deficiency", "Disease", "Anomaly"};
        MutationKind[] kinds = MutationKind.values();

        int syntheticCount = totalDiseases - diseases.size();
        for (int n = 1; n <= syntheticCount; n++) {
            String id = String.format("SYN%04d", n);
            String gene = genePrefixes[genRnd.nextInt(genePrefixes.length)] + (100 + genRnd.nextInt(900));
            String name = gene + " " + nameSuffixes[genRnd.nextInt(nameSuffixes.length)];

            int len = 20 + genRnd.nextInt(21); // reference length 20-40 bp
            StringBuilder refBuilder = new StringBuilder(len);
            for (int k = 0; k < len; k++) refBuilder.append(bases[genRnd.nextInt(4)]);
            String reference = refBuilder.toString();

            MutationKind kind = kinds[genRnd.nextInt(kinds.length)];
            String description;
            int pos; char newBase = ' '; int delLen = 0; String insSeq = null;

            switch (kind) {
                case SUBSTITUTION: {
                    pos = genRnd.nextInt(len);
                    char original = reference.charAt(pos);
                    do { newBase = bases[genRnd.nextInt(4)]; } while (newBase == original);
                    description = "Position " + (pos + 1) + ": " + original + "->" + newBase
                            + " (illustrative point mutation)";
                    break;
                }
                case DELETION: {
                    delLen = 1 + genRnd.nextInt(3); // 1-3 bp
                    pos = genRnd.nextInt(len - delLen);
                    description = (pos + 1) + "-" + (pos + delLen)
                            + ": " + delLen + "-bp illustrative deletion";
                    break;
                }
                default: { // INSERTION
                    int insLen = 1 + genRnd.nextInt(4); // 1-4 bp
                    StringBuilder ins = new StringBuilder(insLen);
                    for (int k = 0; k < insLen; k++) ins.append(bases[genRnd.nextInt(4)]);
                    insSeq = ins.toString();
                    pos = genRnd.nextInt(len + 1);
                    description = insLen + "-bp insertion after position " + pos
                            + " (illustrative frameshift-style change)";
                    break;
                }
            }

            diseases.add(new DiseaseProfile(id, name, gene, reference, kind, description,
                    2, 1, 2, pos, newBase, delLen, insSeq, false));
        }

        return diseases.toArray(new DiseaseProfile[0]);
    }

    /**
     * Builds a 2,000-patient synthetic screening cohort paired 1:1 against a
     * 2,000-entry disease reference panel (the 3 named case-study diseases plus
     * 1,997 randomly generated synthetic diseases), and writes three linked CSV
     * files:
     *   output/diseases.csv           - the 2,000-disease reference panel
     *   output/patients.csv           - patient details, with genome sequence
     *                                   shown right beside the patient ID
     *   output/screening_results.csv  - each patient aligned against the
     *                                   disease they were screened for, again
     *                                   with the genome sequence beside the
     *                                   patient details
     */
    /**
     * Finds the project's output/ folder regardless of the working directory the
     * program is launched from (terminal from out/, VS Code Run from the project
     * root, etc.). Falls back to creating ./output in the current directory if
     * none of the usual relative locations exist.
     */
    private static String resolveOutputDir() {
        String[] candidates = {"output", "../output", "../../output", "./output"};
        for (String c : candidates) {
            java.io.File f = new java.io.File(c);
            if (f.isDirectory()) {
                return f.getPath();
            }
        }
        java.io.File fallback = new java.io.File("output");
        fallback.mkdirs();
        System.out.println("(No existing output/ folder found near working directory \""
                + System.getProperty("user.dir") + "\" - created one at " + fallback.getAbsolutePath() + ")");
        return fallback.getPath();
    }

    private static void multiDiseaseScreening() {
        System.out.println();
        System.out.println("### MULTI-DISEASE SCREENING: 2000 PATIENTS x 2000 DISEASES (1:1 PAIRED) ###");

        final int NUM_PATIENTS = 2000;
        final double MUTATION_RATE = 0.35;
        java.util.Random rnd = new java.util.Random(7);

        DiseaseProfile[] diseases = buildDiseasePanel(NUM_PATIENTS);
        String outDir = resolveOutputDir();
        String diseasesPath = outDir + java.io.File.separator + "diseases.csv";
        String patientsPath = outDir + java.io.File.separator + "patients.csv";
        String resultsPath = outDir + java.io.File.separator + "screening_results.csv";

        System.out.println("Disease panel size        : " + diseases.length
                + " (3 named case-study diseases + " + (diseases.length - 3) + " randomly generated)");
        System.out.println("Named diseases             : "
                + diseases[0].id + " (" + diseases[0].name + "), "
                + diseases[1].id + " (" + diseases[1].name + "), "
                + diseases[2].id + " (" + diseases[2].name + ")");
        System.out.println("Patients                  : " + NUM_PATIENTS + " (each paired 1:1 with one disease)");
        System.out.println("Mutation rate              : ~35% of patients carry their paired disease's mutation");
        System.out.println("Output files               : " + diseasesPath + ", " + patientsPath + ", " + resultsPath);
        System.out.println();

        int namedCarriers = 0, namedNormal = 0;
        double namedSimCarrier = 0, namedSimNormal = 0;
        int synCarriers = 0, synNormal = 0;
        double synSimCarrier = 0, synSimNormal = 0;
        long totalElapsedNanos = 0;

        try (java.io.PrintWriter diseasesCsv = new java.io.PrintWriter(new java.io.FileWriter(diseasesPath));
             java.io.PrintWriter patientsCsv = new java.io.PrintWriter(new java.io.FileWriter(patientsPath));
             java.io.PrintWriter resultsCsv = new java.io.PrintWriter(new java.io.FileWriter(resultsPath))) {

            // ---- File 1: disease reference panel (2,000 rows) ----
            diseasesCsv.println("DiseaseID,DiseaseName,Gene,ReferenceSequence,MutationType,MutationDescription,MatchScore,MismatchPenalty,GapPenalty");
            for (DiseaseProfile d : diseases) {
                diseasesCsv.printf("%s,%s,%s,%s,%s,\"%s\",%d,%d,%d%n",
                        d.id, d.name, d.gene, d.referenceSeq, d.mutationTypeLabel(), d.mutationDescription,
                        d.match, d.mismatch, d.gap);
            }

            // ---- File 2 (patient details + sequence) + File 3 (comparison results) ----
            patientsCsv.println("PatientID,SampleSequence,DiseaseScreened,SampleLength");
            resultsCsv.println("PatientID,SampleSequence,DiseaseID,DiseaseName,AlignmentScore,SimilarityPercent,Matches,Mismatches,Gaps,MutationStatus");

            System.out.println("Detailed comparison - first 100 of " + NUM_PATIENTS + " patients vs their paired disease genome:");
            System.out.printf("%-9s %-9s %-8s %-9s %-9s %-6s %-11s %-20s%n",
                    "Sample", "Match", "Mismatch", "Gaps", "Score", "Disease", "Similarity", "Status");
            System.out.println("-".repeat(85));

            for (int i = 1; i <= NUM_PATIENTS; i++) {
                DiseaseProfile d = diseases[i - 1]; // 1:1 pairing - patient i screened for disease i
                boolean mutated = rnd.nextDouble() < MUTATION_RATE;
                String sample = d.generateSample(mutated, rnd);

                patientsCsv.printf("%d,%s,%s,%d%n", i, sample, d.id, sample.length());

                SmithWaterman sw = new SmithWaterman(d.match, d.mismatch, d.gap);
                AlignmentResult result = sw.align(d.referenceSeq, sample);
                String status = mutated ? "MUTATION DETECTED" : "NORMAL";

                resultsCsv.printf("%d,%s,%s,%s,%d,%.2f,%d,%d,%d,%s%n",
                        i, sample, d.id, d.name, result.score, result.similarityPercent,
                        result.matches, result.mismatches, result.gaps, status);

                totalElapsedNanos += result.elapsedNanos;
                boolean isNamed = i <= 3; // SCA, CF, TSD are diseases[0..2], paired with patients 1-3
                if (mutated) {
                    if (isNamed) { namedCarriers++; namedSimCarrier += result.similarityPercent; }
                    else { synCarriers++; synSimCarrier += result.similarityPercent; }
                } else {
                    if (isNamed) { namedNormal++; namedSimNormal += result.similarityPercent; }
                    else { synNormal++; synSimNormal += result.similarityPercent; }
                }

                if (i <= 100) {
                    System.out.printf("%-9d %-9d %-8d %-9d %-9d %-6s %-11s %-20s%n",
                            i, result.matches, result.mismatches, result.gaps, result.score,
                            d.id, String.format("%.2f%%", result.similarityPercent), status);
                }
            }
        } catch (java.io.IOException e) {
            System.out.println("Could not write one or more CSV files: " + e.getMessage());
            System.out.println("(Working directory was: " + System.getProperty("user.dir") + ")");
            return;
        }

        int totalCarriers = namedCarriers + synCarriers;
        int totalNormal = namedNormal + synNormal;

        System.out.println("... (" + (NUM_PATIENTS - 100) + " more rows in patients.csv / screening_results.csv)");
        System.out.println("-".repeat(85));
        System.out.println("### SCREENING SUMMARY ###");
        System.out.printf("Total Patients Screened     : %d (against %d paired diseases)%n", NUM_PATIENTS, diseases.length);
        System.out.printf("Flagged - Mutation Detected : %d (%.1f%%)%n", totalCarriers, totalCarriers * 100.0 / NUM_PATIENTS);
        System.out.printf("Flagged - Normal             : %d (%.1f%%)%n", totalNormal, totalNormal * 100.0 / NUM_PATIENTS);
        System.out.println();
        System.out.println("Named case-study diseases (SCA, CF, TSD - patients 1-3):");
        System.out.println("   Mutation Detected: " + namedCarriers + "  |  Normal: " + namedNormal);
        System.out.println();
        System.out.println("Randomly generated synthetic diseases (" + (diseases.length - 3) + " diseases, patients 4-2000):");
        System.out.printf("   Screened: %d  |  Mutation Detected: %d (%.1f%%)  |  Normal: %d (%.1f%%)%n",
                synCarriers + synNormal, synCarriers, synCarriers * 100.0 / (synCarriers + synNormal),
                synNormal, synNormal * 100.0 / (synCarriers + synNormal));
        if (synCarriers > 0) {
            System.out.printf("   Avg Similarity (Mutated): %.2f%%%n", synSimCarrier / synCarriers);
        }
        if (synNormal > 0) {
            System.out.printf("   Avg Similarity (Normal) : %.2f%%%n", synSimNormal / synNormal);
        }
        System.out.printf("Total SW Time (%d patients) : %.3f ms%n", NUM_PATIENTS, totalElapsedNanos / 1_000_000.0);
        System.out.printf("Average Time / Patient       : %.4f ms%n",
                (totalElapsedNanos / 1_000_000.0) / NUM_PATIENTS);
    }

    private static void runCase(String label, String nameA, String seqA,
                                 String nameB, String seqB,
                                 int match, int mismatch, int gap, boolean showMatrix) {
        System.out.println("### " + label + " ###");

        SequenceValidator.SequenceType typeA = SequenceValidator.classify(seqA);
        SequenceValidator.SequenceType typeB = SequenceValidator.classify(seqB);
        System.out.println(nameA + " (" + typeA + "): " + seqA);
        System.out.println(nameB + " (" + typeB + "): " + seqB);
        if (typeA == SequenceValidator.SequenceType.INVALID
                || typeB == SequenceValidator.SequenceType.INVALID) {
            System.out.println("Invalid sequence(s) supplied - aborting this case.");
            return;
        }
        System.out.println("Scoring -> match: +" + match + ", mismatch: -" + mismatch + ", gap: -" + gap);
        System.out.println();

        // ---- CO2 stage: Suffix Array + Kasai LCP -> longest common substring
        long saStart = System.nanoTime();
        String lcs = SuffixArrayLCP.longestCommonSubstring(seqA, seqB);
        long saElapsed = System.nanoTime() - saStart;

        System.out.println("[CO2: Suffix Array + Kasai LCP]");
        System.out.println("Longest exact common substring : "
                + (lcs.isEmpty() ? "(none found)" : lcs) + "  (length " + lcs.length() + ")");
        System.out.printf("Execution Time                  : %.3f ms%n", saElapsed / 1_000_000.0);
        System.out.println();

        // ---- CO3 stage: Smith-Waterman local alignment
        System.out.println("[CO3: Smith-Waterman Local Alignment]");
        SmithWaterman sw = new SmithWaterman(match, mismatch, gap);
        AlignmentResult result = sw.align(seqA, seqB);
        result.printReport();

        if (result.mismatches > 0 || result.gaps > 0) {
            System.out.println("=> Difference(s) found between healthy and patient sequence:");
            if (result.mismatches > 0) {
                System.out.println("   - " + result.mismatches
                        + " substitution mutation(s) (point mutation / SNP-style change)");
            }
            if (result.gaps > 0) {
                System.out.println("   - " + result.gaps
                        + " gap position(s) (insertion/deletion, i.e. indel)");
            }
        } else {
            System.out.println("=> No difference detected in the aligned region.");
        }

        if (showMatrix) {
            System.out.println();
            System.out.println("DP Alignment Matrix (rows = Healthy, cols = Patient):");
            for (String row : sw.matrixAsRows(seqA, seqB)) {
                System.out.println(row);
            }
        }
    }

    /** Measures how SW execution time scales with sequence length (CO3 functionality list item). */
    private static void performanceAnalysis() {
        System.out.println();
        System.out.println("### PERFORMANCE ANALYSIS (Smith-Waterman, synthetic DNA sequences) ###");
        SmithWaterman sw = new SmithWaterman(2, 1, 2);
        int[] lengths = {100, 200, 400, 800, 1600};
        for (int len : lengths) {
            String a = randomDna(len, 1);
            String b = randomDna(len, 2);
            long start = System.nanoTime();
            sw.align(a, b);
            long elapsed = System.nanoTime() - start;
            System.out.printf("n = m = %-5d  ->  %.3f ms%n", len, elapsed / 1_000_000.0);
        }
    }

    private static String randomDna(int length, long seed) {
        char[] bases = {'A', 'C', 'G', 'T'};
        java.util.Random rnd = new java.util.Random(seed);
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) sb.append(bases[rnd.nextInt(4)]);
        return sb.toString();
    }
}

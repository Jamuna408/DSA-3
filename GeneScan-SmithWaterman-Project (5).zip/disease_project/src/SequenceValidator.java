/** Validates that an input string is a well-formed DNA or protein sequence. */
public class SequenceValidator {

    private static final String DNA_CHARS = "ACGT";
    private static final String PROTEIN_CHARS = "ACDEFGHIKLMNPQRSTVWY";

    public enum SequenceType { DNA, PROTEIN, INVALID }

    public static SequenceType classify(String seq) {
        if (seq == null || seq.isEmpty()) return SequenceType.INVALID;
        String upper = seq.toUpperCase();

        if (matchesAll(upper, DNA_CHARS)) return SequenceType.DNA;
        if (matchesAll(upper, PROTEIN_CHARS)) return SequenceType.PROTEIN;
        return SequenceType.INVALID;
    }

    private static boolean matchesAll(String seq, String allowedChars) {
        for (char c : seq.toCharArray()) {
            if (allowedChars.indexOf(c) < 0) return false;
        }
        return true;
    }
}

# Description

## Project
**Local Sequence Alignment of DNA and Protein Sequences using the Smith–Waterman Algorithm**

Team: B. Jamuna (2520030408), B. Pemesh (2520030388), P. Anuradha Nandini (2520030171)

## 1. What the system does
The system takes two biological sequences (DNA or protein) and answers two related
questions about them:

1. **Do they share an exact repeated/conserved fragment, and how fast can we find it?**
   Answered using a **Suffix Array + Kasai LCP array** (CO2 — String Algorithms).
2. **What is the best-scoring alignment between them once we allow mismatches and gaps
   (insertions/deletions), as happens with real mutations?**
   Answered using **Smith–Waterman local alignment** (CO3 — Advanced Dynamic Programming).

Running the exact-match stage first and the scored/approximate stage second mirrors how
real bioinformatics pipelines work: cheap exact filtering before expensive alignment.

## 2. Algorithms used and where they map to the syllabus

| Stage | Algorithm | Module / Topic | Role in this project |
|---|---|---|---|
| 1 | **Suffix Array** (prefix-doubling, O(n log² n)) | CO2 — "Suffix arrays: definition ... practical O(n log² n) implementation" | Builds a sorted index of all suffixes of `seqA + separator + seqB` |
| 1 | **Kasai's LCP algorithm** (O(n)) | CO2 — "Longest Common Prefix (LCP) array: the Kasai algorithm in linear time given a suffix array" | Computes longest-common-prefix values between adjacent suffixes in O(n), used to find the **longest exact common substring** — a fast, exact "conserved region" candidate between the two sequences |
| 2 | **Smith–Waterman** (2D DP + traceback) | CO3 — "Sequence alignment for genome data: ... Smith-Waterman (local); the gap-penalty discussion" | Builds the H-matrix using overlapping-subproblem recurrences, finds the maximum-scoring cell, and traces back to reconstruct the optimal **local alignment** allowing mismatches/gaps |

This gives the project one representative algorithm from **each** of the two required
modules, combined into a single coherent pipeline rather than two disconnected demos.

## 3. Why this pairing makes sense
- A suffix array + LCP array can only find **exact** matches — perfect for spotting a
  strongly conserved motif quickly (average/near-linear time), but it says nothing about
  regions that differ by a mutation or a small indel.
- Smith–Waterman handles **approximate** matches (mismatches and gaps) via a scoring
  scheme, but its O(nm) DP table is more expensive than the near-linear suffix-array
  scan.
- Using the fast exact stage first is a realistic bioinformatics pattern (e.g. seed-and-extend
  strategies used by real aligners such as BLAST use exact seeding before local extension).

## 4. Scoring and configuration
The Smith–Waterman implementation accepts three configurable parameters:
- `match` score (reward for identical characters)
- `mismatch` penalty
- `gap` penalty (linear gap model)

Example used in the DNA demo: match = +2, mismatch = −1, gap = −2.
Example used in the protein demo: match = +1, mismatch = −1, gap = −2.

## 5. Data structures used
- `int[][]` — the Smith–Waterman DP / scoring matrix `H[i][j]`
- `char[][]` — traceback direction matrix
- `int[]` (suffix array, rank array, LCP array) for the CO2 stage
- `String` / `StringBuilder` for sequence and alignment construction
- A small `AlignmentResult` value object to carry score, matches, mismatches, gaps,
  and similarity percentage back to the report generator

## 6. Validation
`SequenceValidator` checks every input character against the DNA alphabet (`A,C,G,T`)
or the standard 20-letter amino-acid alphabet before either algorithm runs, and rejects
sequences that match neither.

## 7. Outputs produced
For each pair of sequences the program prints:
- The longest exact common substring found by the suffix array/LCP stage, with timing
- The optimal local alignment (aligned sequence A, match/mismatch indicator line, aligned
  sequence B)
- Alignment score, match count, mismatch count, gap count, percentage similarity
- The region (index range) in each original sequence that the alignment corresponds to
- Execution time for both stages
- (For the DNA example) the full DP alignment matrix
- A performance-analysis run over increasing sequence lengths (100 → 1600) to show how
  Smith–Waterman's O(nm) running time scales, satisfying the "Performance Analysis"
  functionality requirement

See `output/sample_output.txt` for an actual run.

## 8. Tech stack
Plain Java (JDK 21), no external libraries — everything (suffix array, LCP, DP alignment)
is implemented from first principles as required, using core data structures (arrays,
Strings) rather than built-in sequence-alignment libraries.
